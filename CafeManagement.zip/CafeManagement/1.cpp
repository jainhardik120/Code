#include <bits/stdc++.h>
using namespace std;

int main()
{
    system("cd C://Users/Hardik Jain/Downloads && 794.jpg");
    return 0;
}